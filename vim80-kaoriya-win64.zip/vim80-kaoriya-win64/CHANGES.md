## 2017/01/01 の変更点

*   ベースコードを8.0.0134に更新しました
*   contrib 追加
    *   autofmt (2016-12-03 4bf8dbb)
    *   lang-ja (2016-12-08 4c3c613)
    *   LuaJIT (2016-12-30 8e5d7be)
    *   vimdoc-ja (2016-12-23 489d8a0)

## 2016/11/13 の変更点

*   ベースコードを8.0.0082に更新しました
*   diff.exe をバンドルするようにしました
*   contrib 追加
    *   diffutils (2016-11-13 4a42ca2)
*   contrib 更新
    *   LuaJIT (2016-10-20 716f2da)
    *   vimdoc-ja (2016-11-03 6b6b902)

## 2016/10/16 の変更点

*   ベースコードを8.0.0039に更新しました
*   contrib 更新
    *   lang-ja (2016-09-22 8080fc7)
    *   LuaJIT (2016-10-13 3f43f09)
    *   vimdoc-ja (2016-10-14 4a43b59)
*   既知の問題
    *   https://github.com/vim-jp/issues/issues/970

## 2016/09/13 の変更点

*   ベースコードを8.0.0003に更新しました
*   contrib 更新
    *   lang-ja (2016-09-13 57db842)
    *   vimdoc-ja (2016-09-12 da005d9)
*   過去の変更点(CHANGES.txt)を移動しました

    <https://github.com/koron/vim-kaoriya/tree/master/old/CHANGES-7.txt>
