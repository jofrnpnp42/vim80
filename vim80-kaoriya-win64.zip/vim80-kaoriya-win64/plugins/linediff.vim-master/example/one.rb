def one
  two
end

def two
  three
end
